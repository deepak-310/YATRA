<?php
$serevername="localhost";
$username="root";
$password="";
$dbase="yatra";
$conn = mysqli_connect($serevername,$username,$password,$dbase);
    if(!$conn){
        die("connection faild!" . mysqli_connect_error());
    }
    else{
        echo "connection succesful";
    }
$place = $_POST['place'];
$guest = $_POST['guest'];
$adate = $_POST['adate'];
$ldate = $_POST['ldate'];

$query = "INSERT INTO `booking` (`id`, `place`, `guest`, `arrival`,`leaving`) VALUES (NULL, '$place', '$guest', '$adate','$ldate');";
    

if (mysqli_query($conn, $query)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $query . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>