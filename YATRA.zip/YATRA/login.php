<?php
$email=$_POST['email'];
$password=$_POST['pass'];
$serevername="localhost";
$username="root";
$password="";
$dbase="yatra";
$conn = mysqli_connect($serevername,$username,$password,$dbase);
    if(!$conn){
        die("connection faild!" . mysqli_connect_error());
    }
    else{
        $stmt = $conn->prepare("select * from register where email =?");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $stmt_result = $stmt->get_result();
        if($stmt_result->num_rows > 0){
            $data =$stmt_result->fetch_assoc();
            if($data['password']===$password){
                // echo "<h2>login succesful</h2>";
            }
            else{
                echo "<h2>login succesful</h2>";
            }
        }
        else{
            echo "<h2>invalid email or password</h2>";
        }
    }
    

    ?>