<?php
$serevername="localhost";
$username="root";
$password="";
$dbase="yatra";
$conn = mysqli_connect($serevername,$username,$password,$dbase);
    if(!$conn){
        die("connection faild!" . mysqli_connect_error());
    }
    else{
        echo "connection succesful";
    }
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$username=$_POST['uname'];
$password=$_POST['password'];
$cpassword=$_POST['cpassword'];


    if($password==$cpassword){

        $query = "INSERT INTO `register` (`id`, `name`, `email`, `phone`, `username`, `password`, `cpassword`) VALUES (NULL, '$name', '$email', '$phone', '$username', '$password', '$cpassword');";

        if (mysqli_query($conn, $query)) {
            echo "Registration succesfull";
            } else {
            echo "Error: " . $query . "<br>" . mysqli_error($conn);
         }
    }
    else{
        echo "<br>password and confirme password is diffrent plase enter it same";
    }
    
    mysqli_close($conn);


?>